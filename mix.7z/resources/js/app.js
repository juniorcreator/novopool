window.$ = window.jQuery = require('jquery');

// var mySwiper2 = new Swiper('.swiper-container.reviews-swiper', {
//   slidesPerView: 2,
//   spaceBetween: 40,
//   slidesPerGroup: 2,
//   speed: 500,
//   loop: true,
//   autoHeight: true,
//
//   autoplay: {
//     delay: 5000,
//   },
//
//   breakpoints: {
//
//     767: {
//       slidesPerView: 1,
//       slidesPerGroup: 1,
//       spaceBetween: 20
//     },
//
//     991: {
//       slidesPerView: 2,
//       slidesPerGroup: 2,
//       spaceBetween: 20
//     },
//
//   },
//   pagination: {
//     el: '.swiper-pagination',
//     clickable: true,
//   },
//
//   navigation: {
//     nextEl: '.swiper-button-next',
//     prevEl: '.swiper-button-prev',
//   },
// })

//
$('.left-popup__open').click(function () {
  $(".left-popup").addClass("left-popup--active");
});

$('.left-popup__close').click(function () {
  $(".left-popup").removeClass("left-popup--active");
});

$('.js-open-menu').click(function () {
  $(".js-menu").fadeToggle(100);
  document.body.style.overflowY = "hidden";
});

$('.js-close-menu').click(function () {
  $('.js-menu').fadeOut();
  document.body.style.overflowY = "scroll";
});

